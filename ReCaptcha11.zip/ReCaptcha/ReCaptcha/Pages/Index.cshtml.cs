﻿using Griesoft.AspNetCore.ReCaptcha;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace ReCaptcha.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;


        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
        [BindProperty]
   
        public InputModel Input { get; set; }


        [ValidateRecaptcha]
        public class InputModel
        {
            [Required]
            [Display(Name = "First Name")]
            public string FirstName { get; set; }
            [Required]
            [Display(Name = "Last Name")]
            public string LastName { get; set; }
        }


        public void OnGet()
        {

        }

        [HttpPost]
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                RedirectToPage("Error");

            string firstName = Input.FirstName;

            return Page();
        }
    }
}